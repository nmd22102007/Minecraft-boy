# MineRoamer AI v1.0

A small Next.js dashboard + persistent Node.js Mineflayer worker for an **authorized private Minecraft Java server**.

## Important compatibility notes

- Minecraft 26.3 support is provided by the community fork `@wp2508/mineflayer` and `@wp2508/minecraft-data` (community forks, not the official PrismarineJS upstream packages). Pin and test this dependency before production use.
- The bot is a separate Minecraft client. It does not host the Minecraft game server.
- On Enzonic, create **two separate services** if you want both services there:
  1. A Java/Minecraft game-server instance for the world.
  2. A Node.js generic instance for this dashboard + bot.
- Enzonic's Node.js generic free tier is listed as 512 MB RAM / 50% CPU. Running Next.js, Mineflayer, pathfinder and SQLite together may be tight. Watch memory; consider a larger instance if it restarts or runs out of memory.
- This first release only mines `dirt` and `cobblestone`. It does not mine `stone`, because normal stone drops cobblestone and therefore cannot be restored as stone without Silk Touch.
- Restoration is best-effort. It only places a block if the target is still air, the matching item is in inventory, and a valid adjacent reference block exists. Unsupported / obstructed entries stay pending or become skipped.
- Use only on servers where the owner permits bots and automated mining. Do not use it to evade AFK limits, anti-cheat, or server rules.

## Requirements

- Node.js 22 LTS recommended.
- A Minecraft Java 26.3 server reachable from the Enzonic Node.js instance.
- The server owner must permit the bot account.
- For `online-mode=false`, use a private server and a unique bot username. Offline-mode usernames are not authenticated identities; do not expose an offline-mode server to the public internet.

## Local setup

```bash
cp .env.example .env
# Edit .env with your Minecraft server address and dashboard secret
npm install
npm run check
npm run build
npm start
```

Open `http://localhost:3000` and sign in with `DASHBOARD_SECRET`.

## Enzonic deployment

1. Create a Node.js generic server (not a serverless Deploy project) and note the assigned port.
2. Upload this repository or connect your Git repository.
3. Select Node.js 22 if available.
4. Set install command: `npm install`
5. Set build command: `npm run build`
6. Set start command: `npm start`
7. Add environment variables from `.env.example`. Set `PORT` to the port assigned by Enzonic. Set `HOST=0.0.0.0`.
8. Set `MC_HOST`, `MC_PORT`, `MC_USERNAME`, `MC_AUTH=offline`, `MC_VERSION=26.3`.
9. Set `DASHBOARD_SECRET` to a long random value (at least 24 characters).
10. Keep the `data/` directory on persistent storage. Back up `data/mineroamer.sqlite`.

Do not put `.env` in Git. Do not use a public username that impersonates another player.

## Bot behaviour

The worker performs one action at a time:

1. Try to restore the oldest pending block.
2. If nothing can be restored, mine one nearby allowed block.
3. If no block was mined, roam to a safe nearby position.
4. Repeat while connected and not paused.

The loop is deliberately conservative. It does not dig ores, containers, player builds, liquids, or arbitrary blocks.

## Notes on the offline account

`MC_AUTH=offline` is only appropriate for a private server configured with `online-mode=false`. Anyone can claim an offline username. Use a whitelist / network firewall and keep the server private. For a public or online-mode server, use Microsoft authentication instead.

## Troubleshooting

- `Unsupported protocol`: check `MC_VERSION` and the installed community Mineflayer fork version.
- `ECONNREFUSED` / timeout: check host, port, server status, firewall and whether Enzonic can reach the game server.
- `Invalid session`: server may be online-mode or the auth mode is wrong.
- Bot connects but does not move: inspect logs, ensure the bot can move in the world, and check server spawn protection / permissions.
- SQLite native module error: make sure the host supports native npm modules / prebuilt binaries for Node 22.
- Memory pressure: disable dashboard history refresh or move the database to a separate service; upgrade resources if needed.

## Safety defaults

- `BOT_AUTO_START=false`
- Mining radius 4
- Roaming radius 12
- Allowed mining blocks: dirt and cobblestone only
- Reconnect attempts are capped; no unlimited reconnect loop
