const http = require("node:http");
const crypto = require("node:crypto");
const path = require("node:path");
const fs = require("node:fs");
const express = require("express");
const next = require("next");
const cookie = require("cookie");
const { Server } = require("socket.io");
const { z } = require("zod");
const { Database } = require("./apps/bot-engine/src/database");
const { BotManager } = require("./apps/bot-engine/src/bot-manager");

const dev = process.env.NODE_ENV !== "production";
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || "0.0.0.0";
const secret = process.env.DASHBOARD_SECRET || "";
if (secret.length < 24) {
  console.error("DASHBOARD_SECRET must be at least 24 characters. Set it in Enzonic environment variables.");
  process.exit(1);
}
if (!process.env.MC_HOST || !process.env.MC_USERNAME) {
  console.warn("MC_HOST / MC_USERNAME are not set. Configure them before connecting the bot.");
}

const dataDir = path.dirname(path.resolve(process.env.DATABASE_PATH || "./data/mineroamer.sqlite"));
fs.mkdirSync(dataDir, { recursive: true });

const app = next({ dev, dir: path.join(__dirname, "apps/dashboard") });
const handle = app.getRequestHandler();

function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function isAuthed(req) {
  const cookies = cookie.parse(req.headers.cookie || "");
  return safeEqual(cookies.mr_session, secret);
}

function requireAuth(req, res, nextFn) {
  if (!isAuthed(req)) return res.status(401).json({ error: "Please sign in first." });
  nextFn();
}

async function main() {
  await app.prepare();
  const expressApp = express();
  expressApp.disable("x-powered-by");
  expressApp.use(express.json({ limit: "32kb" }));

  const server = http.createServer(expressApp);
  const io = new Server(server, { cors: { origin: false }, maxHttpBufferSize: 1e5 });

  const db = new Database(process.env.DATABASE_PATH || "./data/mineroamer.sqlite");
  const manager = new BotManager({ db, io });

  io.use((socket, nextFn) => {
    const cookies = cookie.parse(socket.handshake.headers.cookie || "");
    if (!safeEqual(cookies.mr_session, secret)) return nextFn(new Error("Unauthorized"));
    nextFn();
  });

  io.on("connection", (socket) => {
    socket.emit("snapshot", manager.snapshot());
  });

  expressApp.post("/api/login", (req, res) => {
    const parsed = z.object({ secret: z.string().min(1) }).safeParse(req.body);
    if (!parsed.success || !safeEqual(parsed.data.secret, secret)) {
      return res.status(401).json({ error: "Invalid dashboard password." });
    }
    res.setHeader("Set-Cookie", cookie.serialize("mr_session", secret, {
      httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production",
      path: "/", maxAge: 60 * 60 * 24 * 7
    }));
    res.json({ ok: true });
  });

  expressApp.post("/api/logout", (req, res) => {
    res.setHeader("Set-Cookie", cookie.serialize("mr_session", "", { httpOnly: true, sameSite: "strict", path: "/", maxAge: 0 }));
    res.json({ ok: true });
  });

  expressApp.get("/api/status", requireAuth, (req, res) => res.json(manager.snapshot()));
  expressApp.get("/api/logs", requireAuth, (req, res) => res.json(db.getLogs(100)));
  expressApp.get("/api/history", requireAuth, (req, res) => res.json(db.getHistory(100)));
  expressApp.get("/api/settings", requireAuth, (req, res) => res.json(db.getSettings()));

  expressApp.patch("/api/settings", requireAuth, (req, res) => {
    const schema = z.object({
      miningEnabled: z.boolean().optional(),
      roamingEnabled: z.boolean().optional(),
      restorationEnabled: z.boolean().optional(),
      miningRadius: z.number().int().min(2).max(6).optional(),
      roamingRadius: z.number().int().min(5).max(24).optional()
    }).strict();
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues });
    db.updateSettings(parsed.data);
    manager.emitSnapshot();
    res.json(db.getSettings());
  });

  expressApp.post("/api/bot/start", requireAuth, async (req, res) => {
    try { await manager.start(); res.json({ ok: true, status: manager.snapshot() }); }
    catch (e) { res.status(400).json({ error: e.message }); }
  });
  expressApp.post("/api/bot/stop", requireAuth, async (req, res) => {
    await manager.stop("Stopped from dashboard");
    res.json({ ok: true });
  });
  expressApp.post("/api/bot/pause", requireAuth, (req, res) => {
    manager.pause(); res.json({ ok: true });
  });
  expressApp.post("/api/bot/resume", requireAuth, (req, res) => {
    manager.resume(); res.json({ ok: true });
  });

  expressApp.use((req, res) => handle(req, res));

  server.listen(port, host, () => {
    console.log(`MineRoamer dashboard listening on ${host}:${port}`);
  });

  if (process.env.BOT_AUTO_START === "true") {
    manager.start().catch(err => console.error("Auto-start failed:", err.message));
  }

  const shutdown = async () => {
    console.log("Shutting down MineRoamer...");
    await manager.stop("Process shutdown");
    io.close();
    server.close(() => process.exit(0));
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
main().catch(err => { console.error(err); process.exit(1); });
