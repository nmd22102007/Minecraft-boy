import "./globals.css";

export const metadata = {
  title: "MineRoamer AI",
  description: "Autonomous Minecraft mining control panel"
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
