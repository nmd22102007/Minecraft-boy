"use client";

import { useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";

const initial = {
  state: "STOPPED", connected: false, paused: false, position: null,
  health: null, food: null, stats: { mined: 0, restored: 0, roamSteps: 0 },
  settings: { miningEnabled: true, roamingEnabled: true, restorationEnabled: true, miningRadius: 4, roamingRadius: 12 },
  pendingRestorations: 0, uptimeSeconds: 0, lastError: null
};

async function api(url, method="GET", body) {
  const res = await fetch(url, {
    method, credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function Stat({ label, value, sub }) {
  return <div className="stat"><span>{label}</span><strong>{value}</strong><small>{sub}</small></div>;
}

export default function Home() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [snapshot, setSnapshot] = useState(initial);
  const [logs, setLogs] = useState([]);
  const [history, setHistory] = useState([]);
  const [settings, setSettings] = useState(initial.settings);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function refresh() {
    const [s, l, h, cfg] = await Promise.all([
      api("/api/status"), api("/api/logs"), api("/api/history"), api("/api/settings")
    ]);
    setSnapshot(s); setLogs(l); setHistory(h); setSettings(cfg);
  }

  useEffect(() => {
    if (!loggedIn) return;
    refresh().catch(e => setError(e.message));
    const socket = io({ withCredentials: true, reconnection: true });
    socket.on("snapshot", setSnapshot);
    socket.on("log", item => setLogs(old => [item, ...old].slice(0, 100)));
    return () => socket.disconnect();
  }, [loggedIn]);

  async function login(e) {
    e.preventDefault(); setError("");
    try {
      await api("/api/login", "POST", { secret: password });
      setLoggedIn(true); setPassword("");
    } catch (e) { setError(e.message); }
  }
  async function action(name) {
    setBusy(true); setError("");
    try { await api(`/api/bot/${name}`, "POST", {}); await refresh(); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function saveSettings() {
    setBusy(true); setError("");
    try { const s = await api("/api/settings", "PATCH", settings); setSettings(s); await refresh(); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function logout() {
    await api("/api/logout", "POST", {});
    setLoggedIn(false); setSnapshot(initial);
  }

  const uptime = useMemo(() => {
    const n = snapshot.uptimeSeconds || 0;
    return `${Math.floor(n/3600)}h ${Math.floor((n%3600)/60)}m`;
  }, [snapshot.uptimeSeconds]);

  if (!loggedIn) return (
    <main className="loginWrap">
      <form className="login card" onSubmit={login}>
        <div className="brandMark">MR</div>
        <p className="eyebrow">AUTONOMOUS CONTROL SYSTEM</p>
        <h1>MineRoamer <em>AI</em></h1>
        <p className="muted">Sign in with the dashboard secret configured on your host.</p>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Dashboard secret" autoComplete="current-password" required />
        {error && <p className="error">{error}</p>}
        <button className="primary full">Open Dashboard</button>
      </form>
    </main>
  );

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand"><div className="brandMark small">MR</div><div><b>MINEROAMER <em>AI</em></b><small>CONTROL CENTER / v1.0</small></div></div>
        <div className="topRight"><span className={`dot ${snapshot.connected ? "online" : ""}`}></span><span>{snapshot.state}</span><button className="ghost" onClick={logout}>Sign out</button></div>
      </header>

      <section className="hero">
        <div><p className="eyebrow">AUTONOMOUS MINING SYSTEM</p><h1>World operations,<br/><em>under control.</em></h1><p className="muted">Monitor exploration, mining and block restoration from one place.</p></div>
        <div className="heroState"><span className={`pulse ${snapshot.connected ? "online" : ""}`}></span><b>{snapshot.connected ? "BOT CONNECTED" : "BOT OFFLINE"}</b><small>{snapshot.username || "No player session"}</small></div>
      </section>

      {error && <div className="alert">{error}</div>}
      {snapshot.lastError && <div className="alert">{snapshot.lastError}</div>}

      <section className="stats">
        <Stat label="BLOCKS MINED" value={snapshot.stats?.mined ?? 0} sub="Successful mining actions"/>
        <Stat label="BLOCKS RESTORED" value={snapshot.stats?.restored ?? 0} sub="Verified placements"/>
        <Stat label="EXPLORATION STEPS" value={snapshot.stats?.roamSteps ?? 0} sub="Completed destinations"/>
        <Stat label="BOT UPTIME" value={uptime} sub={`${snapshot.pendingRestorations || 0} pending restorations`}/>
      </section>

      <section className="gridMain">
        <div className="card controls">
          <div className="sectionHead"><div><p className="eyebrow">BOT CONTROL</p><h2>Operations</h2></div><span className="statePill">{snapshot.state}</span></div>
          <div className="buttonRow">
            <button className="primary" disabled={busy || snapshot.connected} onClick={()=>action("start")}>▶ Start</button>
            <button className="secondary" disabled={busy || !snapshot.connected} onClick={()=>action("pause")}>Ⅱ Pause</button>
            <button className="secondary" disabled={busy || !snapshot.connected || !snapshot.paused} onClick={()=>action("resume")}>↻ Resume</button>
            <button className="danger" disabled={busy || (!snapshot.connected && snapshot.state==="STOPPED")} onClick={()=>action("stop")}>■ Stop</button>
          </div>
          <div className="positionBox"><span>WORLD POSITION</span><strong>{snapshot.position ? `${snapshot.position.x} / ${snapshot.position.y} / ${snapshot.position.z}` : "— / — / —"}</strong><small>Health: {snapshot.health ?? "—"} · Food: {snapshot.food ?? "—"}</small></div>
        </div>

        <div className="card settings">
          <div className="sectionHead"><div><p className="eyebrow">BEHAVIOUR</p><h2>Engine settings</h2></div></div>
          {[
            ["miningEnabled","Mining engine"],["restorationEnabled","Block restoration"],["roamingEnabled","Roaming engine"]
          ].map(([key,label])=><label className="toggleRow" key={key}><span>{label}</span><input type="checkbox" checked={!!settings[key]} onChange={e=>setSettings(s=>({...s,[key]:e.target.checked}))}/></label>)}
          <label className="rangeRow"><span>Mining radius <b>{settings.miningRadius}</b></span><input type="range" min="2" max="6" value={settings.miningRadius} onChange={e=>setSettings(s=>({...s,miningRadius:Number(e.target.value)}))}/></label>
          <label className="rangeRow"><span>Roaming radius <b>{settings.roamingRadius}</b></span><input type="range" min="5" max="24" value={settings.roamingRadius} onChange={e=>setSettings(s=>({...s,roamingRadius:Number(e.target.value)}))}/></label>
          <button className="primary full" disabled={busy} onClick={saveSettings}>Save settings</button>
        </div>
      </section>

      <section className="gridBottom">
        <div className="card">
          <div className="sectionHead"><div><p className="eyebrow">LIVE TELEMETRY</p><h2>Activity log</h2></div></div>
          <div className="logList">{logs.slice(0,14).map((l,i)=><div className="logItem" key={l.id || i}><span className={`logDot ${l.level}`}></span><span>{l.message}</span><time>{l.created_at || l.at || ""}</time></div>)}{logs.length===0 && <p className="muted">No activity yet. Start the bot to see events.</p>}</div>
        </div>
        <div className="card">
          <div className="sectionHead"><div><p className="eyebrow">RESTORATION QUEUE</p><h2>Recent blocks</h2></div></div>
          <div className="tableWrap"><table><thead><tr><th>Block</th><th>Coordinates</th><th>Status</th></tr></thead><tbody>{history.slice(0,12).map(row=><tr key={row.id}><td>{row.block_name}</td><td>{row.x}, {row.y}, {row.z}</td><td><span className={`tag ${row.status}`}>{row.status}</span></td></tr>)}</tbody></table>{history.length===0 && <p className="muted">No blocks mined yet.</p>}</div>
        </div>
      </section>
      <footer>MINEROAMER AI · Use only on servers where bot access and automation are permitted.</footer>
    </main>
  );
}
