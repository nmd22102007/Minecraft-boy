const { goals } = require("mineflayer-pathfinder");

function findSafeDestination(bot, radius) {
  const origin = bot.entity.position;
  for (let attempt = 0; attempt < 18; attempt++) {
    const dx = Math.floor(Math.random() * (radius * 2 + 1)) - radius;
    const dz = Math.floor(Math.random() * (radius * 2 + 1)) - radius;
    if (Math.abs(dx) + Math.abs(dz) < 4) continue;
    const x = Math.floor(origin.x) + dx;
    const z = Math.floor(origin.z) + dz;
    const baseY = Math.floor(origin.y);
    for (let y = baseY + 3; y >= baseY - 6; y--) {
      const floor = bot.blockAt(new (require("vec3").Vec3)(x, y - 1, z));
      const feet = bot.blockAt(new (require("vec3").Vec3)(x, y, z));
      const head = bot.blockAt(new (require("vec3").Vec3)(x, y + 1, z));
      if (floor && floor.boundingBox === "block" &&
          feet && feet.name === "air" && head && head.name === "air") {
        return { x, y, z };
      }
    }
  }
  return null;
}

async function roam(bot, settings, db, log) {
  const destination = findSafeDestination(bot, settings.roamingRadius);
  if (!destination) {
    log("warn", "No safe roaming destination found in loaded area.");
    return false;
  }
  try {
    await bot.pathfinder.goto(new goals.GoalNear(
      destination.x, destination.y, destination.z, 1
    ));
    db.increment("roam_steps");
    log("info", `Explored near ${destination.x},${destination.y},${destination.z}`);
    return true;
  } catch (err) {
    log("warn", `Roaming path failed: ${err.message}`);
    return false;
  }
}

module.exports = { roam };
