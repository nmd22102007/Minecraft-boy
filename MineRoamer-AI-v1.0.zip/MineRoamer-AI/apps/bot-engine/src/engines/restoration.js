const { Vec3 } = require("vec3");

const DIRECTIONS = [
  new Vec3(1,0,0), new Vec3(-1,0,0),
  new Vec3(0,1,0), new Vec3(0,-1,0),
  new Vec3(0,0,1), new Vec3(0,0,-1)
];

async function restoreOne(bot, db, log) {
  const row = db.getPendingBlocks(1)[0];
  if (!row) return false;

  const targetPos = new Vec3(row.x, row.y, row.z);
  const target = bot.blockAt(targetPos);
  if (!target || target.name !== "air") {
    db.markSkipped(row.id);
    log("warn", `Restore skipped at ${row.x},${row.y},${row.z}: target is not air`);
    return false;
  }

  const item = bot.inventory.items().find(i => i.name === row.block_name);
  if (!item) return false; // keep pending until inventory has the block

  let reference = null;
  let face = null;
  for (const dir of DIRECTIONS) {
    const candidate = bot.blockAt(targetPos.plus(dir));
    if (candidate && candidate.boundingBox === "block") {
      reference = candidate;
      face = dir.scaled(-1);
      break;
    }
  }
  if (!reference) return false;

  try {
    await bot.pathfinder.goto(new (require("mineflayer-pathfinder").goals.GoalNear)(
      row.x, row.y, row.z, 3
    ));
    await bot.equip(item, "hand");
    await bot.placeBlock(reference, face);
    const placed = bot.blockAt(targetPos);
    if (placed && placed.name === row.block_name) {
      db.markRestored(row.id);
      db.increment("restored");
      log("info", `Restored ${row.block_name} at ${row.x},${row.y},${row.z}`);
      return true;
    }
  } catch (err) {
    log("warn", `Restore pending: ${err.message}`);
  }
  return false;
}

module.exports = { restoreOne };
