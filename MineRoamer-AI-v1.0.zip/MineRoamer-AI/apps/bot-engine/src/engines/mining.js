const { goals } = require("mineflayer-pathfinder");

// Only blocks whose ordinary drops can be put back as the same block.
const ALLOWED = new Set(["dirt", "cobblestone"]);

async function mineOne(bot, db, settings, log) {
  const block = bot.findBlock({
    matching: b => b && ALLOWED.has(b.name),
    maxDistance: settings.miningRadius,
    count: 1
  });
  if (!block) return false;

  const pos = { x: block.position.x, y: block.position.y, z: block.position.z };
  const name = block.name;

  try {
    await bot.pathfinder.goto(new goals.GoalNear(pos.x, pos.y, pos.z, 2));
    const current = bot.blockAt(block.position);
    if (!current || current.name !== name) return false;

    // Never mine blocks under the player's feet or blocks too close to the bot.
    const p = bot.entity.position;
    if (Math.abs(p.x - (pos.x + 0.5)) < 0.7 &&
        Math.abs(p.z - (pos.z + 0.5)) < 0.7 &&
        Math.abs(p.y - (pos.y + 1)) < 1.1) return false;

    await bot.dig(current);
    db.addMinedBlock(pos, name);
    db.increment("mined");
    log("info", `Mined ${name} at ${pos.x}, ${pos.y}, ${pos.z}`);
    return true;
  } catch (err) {
    log("warn", `Mining skipped: ${err.message}`);
    return false;
  }
}

module.exports = { mineOne };
