const mineflayer = require("@wp2508/mineflayer");
const { pathfinder, Movements } = require("mineflayer-pathfinder");
const { mineOne } = require("./engines/mining");
const { restoreOne } = require("./engines/restoration");
const { roam } = require("./engines/roaming");

class BotManager {
  constructor({ db, io }) {
    this.db = db;
    this.io = io;
    this.bot = null;
    this.state = "STOPPED";
    this.paused = false;
    this.loopRunning = false;
    this.startedAt = null;
    this.lastError = null;
    this.reconnectAttempts = 0;
    this.stopping = false;
    this.loopPromise = null;
  }

  log(level, message) {
    this.db.addLog(level, message);
    this.io.emit("log", { level, message, at: new Date().toISOString() });
    console.log(`[${level}] ${message}`);
  }

  emitSnapshot() { this.io.emit("snapshot", this.snapshot()); }

  snapshot() {
    const pos = this.bot?.entity?.position;
    return {
      state: this.state,
      connected: !!this.bot && !!this.bot.entity,
      paused: this.paused,
      username: this.bot?.username || process.env.MC_USERNAME || "",
      position: pos ? { x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) } : null,
      health: this.bot?.health ?? null,
      food: this.bot?.food ?? null,
      stats: this.db.getStats(),
      settings: this.db.getSettings(),
      pendingRestorations: this.db.getPendingBlocks(1000).length,
      uptimeSeconds: this.startedAt ? Math.floor((Date.now() - this.startedAt) / 1000) : 0,
      lastError: this.lastError
    };
  }

  async start() {
    if (this.bot || this.state === "CONNECTING") return;
    if (!process.env.MC_HOST || !process.env.MC_USERNAME) {
      throw new Error("Set MC_HOST and MC_USERNAME in Enzonic environment variables first.");
    }
    this.stopping = false;
    this.state = "CONNECTING";
    this.lastError = null;
    this.log("info", `Connecting to ${process.env.MC_HOST}:${process.env.MC_PORT || 25565}`);
    this.emitSnapshot();

    const options = {
      host: process.env.MC_HOST,
      port: Number(process.env.MC_PORT || 25565),
      username: process.env.MC_USERNAME,
      auth: process.env.MC_AUTH || "offline",
      version: process.env.MC_VERSION || "26.3",
      hideErrors: false
    };

    this.bot = mineflayer.createBot(options);
    this.bot.loadPlugin(pathfinder);

    this.bot.once("spawn", () => {
      if (!this.bot) return;
      this.reconnectAttempts = 0;
      this.startedAt = this.startedAt || Date.now();
      this.state = "EXPLORING";
      const mcData = require("@wp2508/minecraft-data")(this.bot.version);
      const movements = new Movements(this.bot, mcData);
      movements.canDig = false;
      movements.allow1by1towers = false;
      this.bot.pathfinder.setMovements(movements);
      this.log("success", `Connected as ${this.bot.username} (${this.bot.version})`);
      this.emitSnapshot();
      this.runLoop();
    });

    this.bot.on("health", () => this.emitSnapshot());
    this.bot.on("kicked", reason => {
      this.lastError = `Kicked: ${typeof reason === "string" ? reason : JSON.stringify(reason)}`;
      this.log("error", this.lastError);
    });
    this.bot.on("error", err => {
      this.lastError = err.message;
      this.log("error", `Minecraft error: ${err.message}`);
    });
    this.bot.on("end", () => {
      this.log("warn", "Minecraft connection ended.");
      this.bot = null;
      if (!this.stopping) this.scheduleReconnect();
      else { this.state = "STOPPED"; this.emitSnapshot(); }
    });
  }

  scheduleReconnect() {
    const max = Number(process.env.MAX_RECONNECT_ATTEMPTS || 8);
    if (this.reconnectAttempts >= max) {
      this.state = "ERROR";
      this.log("error", "Reconnect limit reached. Start manually from dashboard.");
      this.emitSnapshot();
      return;
    }
    const attempt = ++this.reconnectAttempts;
    const delay = Math.min(60000, 5000 * attempt);
    this.state = "DISCONNECTED";
    this.emitSnapshot();
    this.log("warn", `Reconnect attempt ${attempt}/${max} in ${Math.round(delay / 1000)}s`);
    setTimeout(() => {
      if (!this.stopping && !this.bot) this.start().catch(e => {
        this.lastError = e.message; this.log("error", e.message);
      });
    }, delay).unref?.();
  }

  async runLoop() {
    if (this.loopRunning) return;
    this.loopRunning = true;
    try {
      while (this.bot && this.bot.entity && !this.stopping) {
        if (this.paused) {
          this.state = "PAUSED";
          await this.sleep(1000);
          continue;
        }
        const settings = this.db.getSettings();
        let didWork = false;

        if (settings.restorationEnabled) {
          this.state = "RESTORING";
          didWork = await restoreOne(this.bot, this.db, (l,m) => this.log(l,m));
        }
        if (!didWork && settings.miningEnabled) {
          this.state = "MINING";
          didWork = await mineOne(this.bot, this.db, settings, (l,m) => this.log(l,m));
        }
        if (!didWork && settings.roamingEnabled) {
          this.state = "EXPLORING";
          didWork = await roam(this.bot, settings, this.db, (l,m) => this.log(l,m));
        }
        if (!didWork) this.state = "IDLE";
        this.emitSnapshot();
        await this.sleep(Number(process.env.LOOP_DELAY_MS || 1800));
      }
    } catch (err) {
      this.lastError = err.message;
      this.log("error", `Bot loop error: ${err.message}`);
      this.state = "ERROR";
    } finally {
      this.loopRunning = false;
      this.emitSnapshot();
    }
  }

  sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
  pause() { this.paused = true; this.state = "PAUSED"; this.log("info", "Bot paused."); this.emitSnapshot(); }
  resume() { this.paused = false; if (this.bot) this.state = "EXPLORING"; this.log("info", "Bot resumed."); this.emitSnapshot(); }

  async stop(reason = "Stopped") {
    this.stopping = true;
    this.paused = false;
    const bot = this.bot;
    this.bot = null;
    if (bot) {
      try { bot.quit(reason); } catch {}
    }
    this.state = "STOPPED";
    this.startedAt = null;
    this.log("info", reason);
    this.emitSnapshot();
  }
}
module.exports = { BotManager };
