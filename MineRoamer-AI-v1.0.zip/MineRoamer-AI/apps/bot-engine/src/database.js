const fs = require("node:fs");
const path = require("node:path");
const DatabaseSync = require("better-sqlite3");

class Database {
  constructor(filename) {
    const full = path.resolve(filename);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    this.db = new DatabaseSync(full);
    this.db.pragma("journal_mode = WAL");
    this.db.pragma("busy_timeout = 5000");
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        mining_enabled INTEGER NOT NULL DEFAULT 1,
        roaming_enabled INTEGER NOT NULL DEFAULT 1,
        restoration_enabled INTEGER NOT NULL DEFAULT 1,
        mining_radius INTEGER NOT NULL DEFAULT 4,
        roaming_radius INTEGER NOT NULL DEFAULT 12
      );
      INSERT OR IGNORE INTO settings (id) VALUES (1);
      CREATE TABLE IF NOT EXISTS block_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        world TEXT NOT NULL DEFAULT 'default',
        x INTEGER NOT NULL, y INTEGER NOT NULL, z INTEGER NOT NULL,
        block_name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        restored_at TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_block_status ON block_history(status, id);
      CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        level TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS stats (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        mined INTEGER NOT NULL DEFAULT 0,
        restored INTEGER NOT NULL DEFAULT 0,
        roam_steps INTEGER NOT NULL DEFAULT 0
      );
      INSERT OR IGNORE INTO stats (id) VALUES (1);
    `);
  }

  getSettings() {
    const r = this.db.prepare("SELECT * FROM settings WHERE id=1").get();
    return {
      miningEnabled: !!r.mining_enabled,
      roamingEnabled: !!r.roaming_enabled,
      restorationEnabled: !!r.restoration_enabled,
      miningRadius: r.mining_radius,
      roamingRadius: r.roaming_radius
    };
  }
  updateSettings(s) {
    const current = this.getSettings();
    const n = { ...current, ...s };
    this.db.prepare(`UPDATE settings SET mining_enabled=?, roaming_enabled=?, restoration_enabled=?, mining_radius=?, roaming_radius=? WHERE id=1`)
      .run(+n.miningEnabled, +n.roamingEnabled, +n.restorationEnabled, n.miningRadius, n.roamingRadius);
  }
  addLog(level, message) {
    this.db.prepare("INSERT INTO logs(level,message) VALUES(?,?)").run(level, String(message).slice(0, 500));
  }
  getLogs(limit=100) {
    return this.db.prepare("SELECT * FROM logs ORDER BY id DESC LIMIT ?").all(limit);
  }
  addMinedBlock(pos, name) {
    return this.db.prepare("INSERT INTO block_history(x,y,z,block_name,status) VALUES(?,?,?,?, 'pending')")
      .run(pos.x, pos.y, pos.z, name).lastInsertRowid;
  }
  getPendingBlocks(limit=30) {
    return this.db.prepare("SELECT * FROM block_history WHERE status='pending' ORDER BY id ASC LIMIT ?").all(limit);
  }
  markRestored(id) {
    this.db.prepare("UPDATE block_history SET status='restored', restored_at=CURRENT_TIMESTAMP WHERE id=?").run(id);
  }
  markSkipped(id) {
    this.db.prepare("UPDATE block_history SET status='skipped' WHERE id=?").run(id);
  }
  increment(key) {
    const allowed = ["mined", "restored", "roam_steps"];
    if (!allowed.includes(key)) return;
    this.db.prepare(`UPDATE stats SET ${key}=${key}+1 WHERE id=1`).run();
  }
  getStats() {
    return this.db.prepare("SELECT mined, restored, roam_steps AS roamSteps FROM stats WHERE id=1").get();
  }
  getHistory(limit=100) {
    return this.db.prepare("SELECT * FROM block_history ORDER BY id DESC LIMIT ?").all(limit);
  }
  close() { this.db.close(); }
}
module.exports = { Database };
